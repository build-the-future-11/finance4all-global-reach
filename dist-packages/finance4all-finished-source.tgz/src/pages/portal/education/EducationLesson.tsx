import { Link, useParams } from "react-router-dom";
import { ArrowLeft, CheckCircle2, Clock } from "lucide-react";
import { useEducationLesson } from "@/hooks/portal/useEducation";
import { useEducationProgress } from "@/hooks/portal/useEducationProgress";
import MarkdownContent from "@/components/portal/MarkdownContent";
import { LoadingState, PortalCard, PortalPageHeader, portalButtonOutline, portalButtonPrimary } from "@/components/portal/PortalUI";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { portalRoutes } from "@/routes/portal";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";
import { portalCopy } from "@/lib/portalCopy";
import PortalAnimatedSection from "@/components/portal/PortalAnimatedSection";

export default function EducationLesson() {
  const { lessonId } = useParams();
  const { data: lessonData, isLoading } = useEducationLesson(lessonId);
  const { toggleLesson, isLessonComplete, isSyncing } = useEducationProgress();

  const lesson = lessonData?.lesson;
  const content = lessonData?.content;
  const done = lessonId ? isLessonComplete(lessonId) : false;

  useDocumentTitle(lesson?.title ?? "Lesson");

  if (isLoading) {
    return (
      <div className="min-h-[40vh]">
        <LoadingState />
      </div>
    );
  }

  if (!lesson || !content) {
    return (
      <div>
        <Link to={portalRoutes.education} className="text-sm text-emerald-300 hover:underline">
          ← Education hub
        </Link>
        <p className="mt-6 text-white/60">{portalCopy.education.lessonNotFound}</p>
      </div>
    );
  }

  return (
    <div>
      <PortalAnimatedSection>
        <Link
          to={portalRoutes.education}
          className="mb-6 inline-flex items-center gap-2 text-sm text-emerald-300 hover:underline"
        >
          <ArrowLeft className="h-4 w-4" /> {lesson.module.title}
        </Link>

        <PortalPageHeader
          eyebrow={lesson.module.eyebrow}
          title={lesson.title}
          description={lesson.summary}
          action={
            <Badge variant="outline" className="border-white/20 text-white/60">
              <Clock className="mr-1 h-3 w-3" />
              {lesson.durationMin} min read
            </Badge>
          }
        />
      </PortalAnimatedSection>

      <div className="mb-6 flex flex-wrap gap-2">
        {content.keyTerms.map((term) => (
          <span
            key={term}
            className="rounded-md border border-white/10 bg-white/[0.04] px-2.5 py-1 text-xs text-white/55"
          >
            {term}
          </span>
        ))}
        <span className="text-xs text-white/35">{lesson.durationMin} min read</span>
      </div>

      <PortalCard className="p-6 sm:p-8">
        <MarkdownContent content={content.body} />
      </PortalCard>

      <PortalCard className="mt-6 border-emerald-400/15 p-6">
        <h2 className="font-semibold text-white">{portalCopy.education.exerciseTitle}</h2>
        <div className="mt-3 text-sm leading-relaxed text-white/65">
          <MarkdownContent content={content.exercise} />
        </div>
      </PortalCard>

      <div className="mt-8 flex flex-wrap gap-3">
        <Button
          onClick={() => toggleLesson(lesson.id)}
          disabled={isSyncing}
          className={done ? portalButtonOutline : portalButtonPrimary}
          variant={done ? "outline" : "default"}
        >
          {done && <CheckCircle2 className="mr-2 h-4 w-4" />}
          {done ? portalCopy.education.markUndo : portalCopy.education.markComplete}
        </Button>
        <Link to={portalRoutes.debriefedExplainers}>
          <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
            {portalCopy.education.relatedExplainers}
          </Button>
        </Link>
      </div>
    </div>
  );
}
